#ifndef _GLOBALS_H
#define _GLOBALS_H

typedef double MY_FLOAT;

#endif


