/* stkinit.h -- set up stk path */

#ifdef __cplusplus
extern "C" {
#endif

void stk_init();

#ifdef __cplusplus
}
#endif
