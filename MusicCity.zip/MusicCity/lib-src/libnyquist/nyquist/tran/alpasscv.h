sound_type snd_make_alpasscv(sound_type input, time_type delay, sound_type feedback);
sound_type snd_alpasscv(sound_type input, time_type delay, sound_type feedback);
    /* LISP: (snd-alpasscv SOUND ANYNUM SOUND) */
