sound_type snd_make_amosc(sound_type input, double step, rate_type sr, double hz, time_type t0, sound_type amod, double phase);
sound_type snd_amosc(sound_type input, double step, rate_type sr, double hz, time_type t0, sound_type amod, double phase);
    /* LISP: (snd-amosc SOUND ANYNUM ANYNUM ANYNUM ANYNUM SOUND ANYNUM) */
