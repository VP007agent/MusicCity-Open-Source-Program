sound_type snd_make_allpoles(sound_type x_snd, LVAL ak_array, double gain);
sound_type snd_allpoles(sound_type x_snd, LVAL ak_array, double gain);
    /* LISP: (snd-allpoles SOUND ANY ANYNUM) */
