sound_type snd_make_delay(sound_type input, time_type delay, double feedback);
sound_type snd_delay(sound_type input, time_type delay, double feedback);
    /* LISP: (snd-delay SOUND ANYNUM ANYNUM) */
