sound_type snd_make_chase(sound_type input, double risetime, double falltime);
sound_type snd_chase(sound_type input, double risetime, double falltime);
    /* LISP: (snd-chase SOUND ANYNUM ANYNUM) */
