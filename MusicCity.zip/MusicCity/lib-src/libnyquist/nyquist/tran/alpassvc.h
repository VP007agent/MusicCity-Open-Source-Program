sound_type snd_make_alpassvc(sound_type input, sound_type delaysnd, double feedback, double maxdelay);
sound_type snd_alpassvc(sound_type input, sound_type delaysnd, double feedback, double maxdelay);
    /* LISP: (snd-alpassvc SOUND SOUND ANYNUM ANYNUM) */
