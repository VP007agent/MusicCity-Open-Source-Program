sound_type snd_make_down(rate_type sr, sound_type s);
sound_type snd_down(rate_type sr, sound_type s);
    /* LISP: (snd-down ANYNUM SOUND) */
