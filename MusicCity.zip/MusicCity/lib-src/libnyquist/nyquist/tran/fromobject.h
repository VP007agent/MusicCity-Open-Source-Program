sound_type snd_make_fromobject(time_type t0, rate_type sr, LVAL src);
sound_type snd_fromobject(time_type t0, rate_type sr, LVAL src);
    /* LISP: (snd-fromobject ANYNUM ANYNUM ANY) */
