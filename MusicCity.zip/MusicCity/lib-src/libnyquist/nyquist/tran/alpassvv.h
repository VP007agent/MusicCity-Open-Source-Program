sound_type snd_make_alpassvv(sound_type input, sound_type delaysnd, sound_type feedback, double maxdelay);
sound_type snd_alpassvv(sound_type input, sound_type delaysnd, sound_type feedback, double maxdelay);
    /* LISP: (snd-alpassvv SOUND SOUND SOUND ANYNUM) */
