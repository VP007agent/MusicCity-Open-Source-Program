sound_type snd_make_clip(sound_type s, double level);
sound_type snd_clip(sound_type s, double level);
    /* LISP: (snd-clip SOUND ANYNUM) */
