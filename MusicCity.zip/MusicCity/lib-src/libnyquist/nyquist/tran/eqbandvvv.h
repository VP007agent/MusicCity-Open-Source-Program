sound_type snd_make_eqbandvvv(sound_type input, sound_type hz, sound_type gain, sound_type width);
sound_type snd_eqbandvvv(sound_type input, sound_type hz, sound_type gain, sound_type width);
    /* LISP: (snd-eqbandvvv SOUND SOUND SOUND SOUND) */
