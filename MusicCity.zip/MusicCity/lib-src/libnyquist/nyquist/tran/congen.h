sound_type snd_make_congen(sound_type sndin, double risetime, double falltime);
sound_type snd_congen(sound_type sndin, double risetime, double falltime);
    /* LISP: (snd-congen SOUND ANYNUM ANYNUM) */
