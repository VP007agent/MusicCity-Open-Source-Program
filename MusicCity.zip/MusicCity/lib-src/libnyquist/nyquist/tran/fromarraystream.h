sound_type snd_make_fromarraystream(time_type t0, rate_type sr, LVAL src);
sound_type snd_fromarraystream(time_type t0, rate_type sr, LVAL src);
    /* LISP: (snd-fromarraystream ANYNUM ANYNUM ANY) */
