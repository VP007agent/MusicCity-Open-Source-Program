sound_type snd_make_alpass(sound_type input, time_type delay, double feedback);
sound_type snd_alpass(sound_type input, time_type delay, double feedback);
    /* LISP: (snd-alpass SOUND ANYNUM ANYNUM) */
