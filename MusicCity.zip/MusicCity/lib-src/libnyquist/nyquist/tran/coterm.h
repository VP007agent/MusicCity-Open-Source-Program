sound_type snd_make_coterm(sound_type s1, sound_type s2);
sound_type snd_coterm(sound_type s1, sound_type s2);
    /* LISP: (snd-coterm SOUND SOUND) */
