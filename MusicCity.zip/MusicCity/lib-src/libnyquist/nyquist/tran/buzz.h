sound_type snd_make_buzz(long n, rate_type sr, double hz, time_type t0, sound_type s_fm);
sound_type snd_buzz(long n, rate_type sr, double hz, time_type t0, sound_type s_fm);
    /* LISP: (snd-buzz FIXNUM ANYNUM ANYNUM ANYNUM SOUND) */
