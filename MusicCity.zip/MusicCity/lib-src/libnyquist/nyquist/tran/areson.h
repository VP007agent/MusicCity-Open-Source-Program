sound_type snd_make_areson(sound_type input, double hz, double bw, int normalization);
sound_type snd_areson(sound_type input, double hz, double bw, int normalization);
    /* LISP: (snd-areson SOUND ANYNUM ANYNUM FIXNUM) */
