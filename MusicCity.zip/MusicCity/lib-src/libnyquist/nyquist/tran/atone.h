sound_type snd_make_atone(sound_type s, double hz);
sound_type snd_atone(sound_type s, double hz);
    /* LISP: (snd-atone SOUND ANYNUM) */
