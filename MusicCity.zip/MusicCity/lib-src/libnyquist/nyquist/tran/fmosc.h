sound_type snd_make_fmosc(sound_type s, double step, rate_type sr, double hz, time_type t0, sound_type s_fm, double phase);
sound_type snd_fmosc(sound_type s, double step, rate_type sr, double hz, time_type t0, sound_type s_fm, double phase);
    /* LISP: (snd-fmosc SOUND ANYNUM ANYNUM ANYNUM ANYNUM SOUND ANYNUM) */
