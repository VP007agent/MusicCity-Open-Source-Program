sound_type snd_make_bowed(double freq, sound_type bowpress_env, rate_type sr);
sound_type snd_bowed(double freq, sound_type bowpress_env, rate_type sr);
    /* LISP: (snd-bowed ANYNUM SOUND ANYNUM) */
#define BOW_CONTROL_CHANGE_CONST 128
