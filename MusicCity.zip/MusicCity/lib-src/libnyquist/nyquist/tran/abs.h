sound_type snd_make_abs(sound_type input);
sound_type snd_abs(sound_type input);
    /* LISP: (snd-abs SOUND) */
