sound_type snd_make_ifft(time_type t0, rate_type sr, LVAL src, long stepsize, LVAL window);
sound_type snd_ifft(time_type t0, rate_type sr, LVAL src, long stepsize, LVAL window);
    /* LISP: (snd-ifft ANYNUM ANYNUM ANY FIXNUM ANY) */
