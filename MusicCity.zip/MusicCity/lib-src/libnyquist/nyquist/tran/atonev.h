sound_type snd_make_atonev(sound_type s1, sound_type hz);
sound_type snd_atonev(sound_type s1, sound_type hz);
    /* LISP: (snd-atonev SOUND SOUND) */
