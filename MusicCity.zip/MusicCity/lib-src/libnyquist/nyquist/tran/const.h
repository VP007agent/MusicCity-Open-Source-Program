sound_type snd_make_const(double c, time_type t0, rate_type sr, time_type d);
sound_type snd_const(double c, time_type t0, rate_type sr, time_type d);
    /* LISP: (snd-const ANYNUM ANYNUM ANYNUM ANYNUM) */
