sound_type snd_make_aresonvv(sound_type s1, sound_type hz1, sound_type bw, int normalization);
sound_type snd_aresonvv(sound_type s1, sound_type hz1, sound_type bw, int normalization);
    /* LISP: (snd-aresonvv SOUND SOUND SOUND FIXNUM) */
