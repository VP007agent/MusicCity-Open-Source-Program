sound_type snd_make_aresoncv(sound_type s1, double hz, sound_type bw, int normalization);
sound_type snd_aresoncv(sound_type s1, double hz, sound_type bw, int normalization);
    /* LISP: (snd-aresoncv SOUND ANYNUM SOUND FIXNUM) */
