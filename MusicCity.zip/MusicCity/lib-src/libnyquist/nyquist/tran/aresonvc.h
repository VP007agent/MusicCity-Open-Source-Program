sound_type snd_make_aresonvc(sound_type s1, sound_type hz, double bw, int normalization);
sound_type snd_aresonvc(sound_type s1, sound_type hz, double bw, int normalization);
    /* LISP: (snd-aresonvc SOUND SOUND ANYNUM FIXNUM) */
