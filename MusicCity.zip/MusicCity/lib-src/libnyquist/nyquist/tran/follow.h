sound_type snd_make_follow(sound_type sndin, double floor, double risetime, double falltime, long lookahead);
sound_type snd_follow(sound_type sndin, double floor, double risetime, double falltime, long lookahead);
    /* LISP: (snd-follow SOUND ANYNUM ANYNUM ANYNUM FIXNUM) */
