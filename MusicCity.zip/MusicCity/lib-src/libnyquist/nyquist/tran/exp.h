sound_type snd_make_exp(sound_type in);
sound_type snd_exp(sound_type in);
    /* LISP: (snd-exp SOUND) */
