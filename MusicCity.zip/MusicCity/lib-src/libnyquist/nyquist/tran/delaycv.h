sound_type snd_make_delaycv(sound_type s, time_type delay, sound_type feedback);
sound_type snd_delaycv(sound_type s, time_type delay, sound_type feedback);
    /* LISP: (snd-delaycv SOUND ANYNUM SOUND) */
