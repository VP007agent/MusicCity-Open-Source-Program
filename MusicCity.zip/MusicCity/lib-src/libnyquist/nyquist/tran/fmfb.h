sound_type snd_make_fmfb(time_type t0, double hz, rate_type sr, double index, time_type d);
sound_type snd_fmfb(time_type t0, double hz, rate_type sr, double index, time_type d);
    /* LISP: (snd-fmfb ANYNUM ANYNUM ANYNUM ANYNUM ANYNUM) */
#include "sine.h" /* sine_table and SINE_TABLE_LEN */
