sound_type snd_make_bowed_freq(double freq, sound_type bowpress_env, sound_type freq_env, rate_type sr);
sound_type snd_bowed_freq(double freq, sound_type bowpress_env, sound_type freq_env, rate_type sr);
    /* LISP: (snd-bowed_freq ANYNUM SOUND SOUND ANYNUM) */
#define BOW_CONTROL_CHANGE_CONST 128
