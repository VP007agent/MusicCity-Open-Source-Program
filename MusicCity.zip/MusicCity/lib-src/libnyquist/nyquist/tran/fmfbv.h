sound_type snd_make_fmfbv(time_type t0, double hz, rate_type sr, sound_type index);
sound_type snd_fmfbv(time_type t0, double hz, rate_type sr, sound_type index);
    /* LISP: (snd-fmfbv ANYNUM ANYNUM ANYNUM SOUND) */
#include "sine.h" /* sine_table and SINE_TABLE_LEN */
