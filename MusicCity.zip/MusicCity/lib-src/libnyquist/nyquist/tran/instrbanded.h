sound_type snd_make_bandedwg(double freq, sound_type bowpress_env, int preset, rate_type sr);
sound_type snd_bandedwg(double freq, sound_type bowpress_env, int preset, rate_type sr);
    /* LISP: (snd-bandedwg ANYNUM SOUND FIXNUM ANYNUM) */
#define BANDEDWG_CONTROL_CHANGE_CONST 128
