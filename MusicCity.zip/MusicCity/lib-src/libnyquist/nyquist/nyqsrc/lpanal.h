/* lpanal.h -- LPC analysis */

LVAL snd_lpanal(LVAL v, long P);
  /* LISP: (SND-LPANAL ANY FIXNUM) */
