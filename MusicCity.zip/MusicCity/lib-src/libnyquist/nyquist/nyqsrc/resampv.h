sound_type snd_make_resamplev(sound_type f, rate_type sr, sound_type g);
sound_type snd_resamplev(sound_type f, rate_type sr, sound_type g);
    /* LISP: (snd-resamplev SOUND ANYNUM SOUND) */
