/* yin.h -- Nyquist code for F0 estimation using YIN approach */


LVAL snd_yin(sound_type s, double low_step, double high_step, long stepsize);
/* LISP: (SND-YIN SOUND ANYNUM ANYNUM FIXNUM) */

