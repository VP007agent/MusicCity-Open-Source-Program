sound_type snd_make_sndseq();
sound_type snd_sndseq();
    /* LISP: (SND-SEQ SOUND ANY) */
