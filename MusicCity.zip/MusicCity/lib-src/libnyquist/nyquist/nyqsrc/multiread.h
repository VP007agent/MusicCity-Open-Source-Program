LVAL multiread_create(read_susp_type susp);
void multiread_fetch(snd_susp_type a_susp, snd_list_type snd_list);
void multiread_free(snd_susp_type a_susp);
