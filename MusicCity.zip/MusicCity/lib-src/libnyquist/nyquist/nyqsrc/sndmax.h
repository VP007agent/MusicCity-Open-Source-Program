/* sndmax.h -- header to write sounds to files */

double sound_max(LVAL snd_expr, long n);
/* LISP: (SND-MAX ANY FIXNUM) */
