sound_type snd_make_trigger();
sound_type snd_trigger();
    /* LISP: (SND-TRIGGER SOUND ANY) */
