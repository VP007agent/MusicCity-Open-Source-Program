sound_type snd_make_compose(sound_type f, sound_type g);
sound_type snd_compose(sound_type f, sound_type g);
    /* LISP: (snd-compose SOUND SOUND) */
