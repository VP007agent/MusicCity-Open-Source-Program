/*
 *  nyq-osc-server.h
 *  nyquist
 *
 *  Created by Roger Dannenberg
 */

int nosc_init();
int nosc_poll();
void nosc_finish();
