sound_type snd_make_inverse(sound_type s, time_type t0, rate_type sr);
sound_type snd_inverse(sound_type s, time_type t0, rate_type sr);
    /* LISP: (snd-inverse SOUND ANYNUM ANYNUM) */
