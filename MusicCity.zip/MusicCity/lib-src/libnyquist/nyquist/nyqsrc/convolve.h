sound_type snd_make_convolve(sound_type x_snd, sound_type h_snd);
sound_type snd_convolve(sound_type x_snd, sound_type h_snd);
    /* LISP: (snd-convolve SOUND SOUND) */
