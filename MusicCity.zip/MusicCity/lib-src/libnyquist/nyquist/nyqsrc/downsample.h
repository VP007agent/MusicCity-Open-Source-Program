sound_type snd_make_down();
sound_type snd_down();
    /* LISP: (snd-down ANYNUM SOUND) */
