/* exitpa.h -- declare portaudio_exit() */

void portaudio_exit();
