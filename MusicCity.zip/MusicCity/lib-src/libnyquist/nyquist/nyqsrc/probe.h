/* probe.h -- used to test resampling */

void probe_init(int readflag);
double probe(char *s, double x);
double probe2(char *s, double x);

