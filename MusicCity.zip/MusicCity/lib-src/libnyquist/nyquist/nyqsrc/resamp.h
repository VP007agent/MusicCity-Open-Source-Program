sound_type snd_make_resample(sound_type s, rate_type sr);
sound_type snd_resample(sound_type s, rate_type sr);
    /* LISP: (snd-resample SOUND ANYNUM) */
