/* seqmread.h -- midi file reader */

void seq_read_smf(seq_type seq, FILE *fp); /* LISP: (SEQ-READ-SMF SEQ FILE) */

