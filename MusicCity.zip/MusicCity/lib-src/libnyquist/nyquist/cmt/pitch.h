/* mbc code */
/* Copyright 1989 Carnegie Mellon University */

typedef struct pitch_struct {
    int ppitch;
    int pbend;
} 
pitch_table;
/* end */
