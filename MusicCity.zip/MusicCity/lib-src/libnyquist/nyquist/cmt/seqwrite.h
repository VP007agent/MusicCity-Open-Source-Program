/* seqwrite.h -- write adagio format file */
/* Copyright 1994 Carnegie Mellon University */

void seq_write(seq_type seq, FILE *f, boolean abs_flag);
        /* LISP: (SEQ-WRITE SEQ FILE BOOLEAN) */

