/* seqmwrite.h -- midi file writer */

void seq_write_smf(seq_type seq, FILE *outfile); /* LISP: (SEQ-WRITE-SMF SEQ FILE) */

