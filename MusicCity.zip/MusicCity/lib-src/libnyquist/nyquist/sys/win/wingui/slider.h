// slider.h -- simple slider input

#define NUMSLIDERS 9
extern HWND sliders[NUMSLIDERS];

void set_slider_pos(HWND hwnd, int ival);
