class typein {
public:
    static longque queue;
    static void init(void);
    static void finish(void);
    static void handler(char *inp);
};

