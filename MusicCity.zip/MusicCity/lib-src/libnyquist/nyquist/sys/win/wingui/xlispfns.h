#ifdef __cplusplus
extern "C" {
#endif

void run_xlisp();

#ifdef __cplusplus
}
#endif
