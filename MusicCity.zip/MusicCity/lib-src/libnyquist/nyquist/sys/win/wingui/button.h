// button.h -- simple slider input

