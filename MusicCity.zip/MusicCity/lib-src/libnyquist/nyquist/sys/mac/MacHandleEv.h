/* MacHandelEv.h -- event handlers */

void DoMouseDown(EventRecord *theEvent);
