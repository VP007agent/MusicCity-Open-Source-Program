{	"HIDEPEN",			S, xhidepen		}, /* 300 */

{	"SHOWPEN",			S, xshowpen		}, /* 301 */

{	"GETPEN",			S, xgetpen		}, /* 302 */

{	"PENSIZE",			S, xpensize		}, /* 303 */

{	"PENMODE",			S, xpenmode		}, /* 304 */

{	"PENPAT",			S, xpenpat		}, /* 305 */

{	"PENNORMAL",			S, xpennormal		}, /* 306 */

{	"MOVETO",			S, xmoveto		}, /* 307 */

{	"MOVE",				S, xmove		}, /* 308 */

{	"LINETO",			S, xdrawto		}, /* 309 */

{	"LINE",				S, xdraw		}, /* 310 */

{	"SHOW-GRAPHICS",		S, xshowgraphics	}, /* 311 */

{	"HIDE-GRAPHICS",		S, xhidegraphics	}, /* 312 */

{	"CLEAR-GRAPHICS",		S, xcleargraphics	}, /* 313 */

{	"TOOLBOX",			S, xtool		}, /* 314 */

{	"TOOLBOX-16",			S, xtool16		}, /* 315 */

{	"TOOLBOX-32",			S, xtool32		}, /* 316 */

{	"NEWHANDLE",			S, xnewhandle		}, /* 317 */

{	"NEWPTR",			S, xnewptr		}, /* 318 */

{	"HIWORD",			S, xhiword		}, /* 319 */

{	"LOWORD",			S, xloword		}, /* 320 */

{	"READ-CHAR-NO-HANG",		S, xrdnohang		}, /* 321 */



/* not implemented - take a look at code in directory "sys:mac:old" */

/*{	"COMMAND-POINT-SIZE",		S, xptsize		},  322 */



