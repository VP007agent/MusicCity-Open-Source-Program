/* MacFileUtils.h -- more mac stuff */

void GetFullPath(FSSpec *theSpec, StringPtr theName);
