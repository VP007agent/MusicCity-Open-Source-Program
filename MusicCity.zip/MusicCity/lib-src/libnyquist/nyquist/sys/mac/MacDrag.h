/* MacDrag.h -- drag text */

Boolean DragText(EventRecord *ev);
