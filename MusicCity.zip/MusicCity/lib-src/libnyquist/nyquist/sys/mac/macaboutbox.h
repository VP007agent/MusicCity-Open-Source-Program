/* macaboutbox.h -- header for about box implementation */

void DoAboutBox(void);
