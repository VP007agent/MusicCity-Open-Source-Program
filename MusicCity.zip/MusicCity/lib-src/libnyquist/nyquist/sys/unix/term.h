void term_init();
void term_exit();
void ctcinit(); /* not implemented in term.h */
int term_testchar();
int term_getchar();
void term_character();
